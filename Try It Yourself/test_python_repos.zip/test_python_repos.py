'''
17-3. Testing python_repos.py: In python_repos.py, we printed the value of
status_code to make sure the API call was successful. Write a program called
test_python_repos.py that uses unittest to assert that the value of status_code
is 200. Figure out some other assertions you can make—for example, that the
number of items returned is expected and that the total number of repositories
is greater than a certain amount.
'''

import unittest

from test_python_repos2 import get_repo, get_items, get_totals


class RepoTestCase(unittest.TestCase):

    # This method tests the get_repo function from test_python_repos2
    def test1(self):
        # This stores the return value from the get_repo function in the variable status
        status = get_repo()
        # This line compares the value returned in the variable above called status and checks if it's equal to 200
        self.assertEqual(status, 200)
        print("Test1 checks if status is equal to 200")

    def test2(self):
        items = get_items()
        self.assertEqual(items, 30)
        print("Test2 checks the total number of repositories")

    def test3(self):
        total = get_totals()
        self.assertGreater(total, 21)
        print("Test3 checks if the number of repositories is greater")


if __name__ == '__main__':
    unittest.main()

